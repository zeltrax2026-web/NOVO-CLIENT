#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

if ! command -v java >/dev/null 2>&1; then
  echo "Java is missing. Install JDK 21 first: pkg install openjdk-21"
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is missing. Install it with: pkg install gradle"
  exit 1
fi
java -version
gradle --no-daemon build

echo
echo "Build finished. Check build/libs/ for the remapped NOVA JAR."
