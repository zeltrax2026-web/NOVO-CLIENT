# NOVA Client — Fabric 1.21.11 (NEXUS starter)

A client-side Fabric mod project targeting Minecraft Java 1.21.11, Java 21 and Fabric Loader 0.18.1. The current milestone contains a working NEXUS menu foundation, category navigation, clickable module-state toggles, a low-cost animated starfield background, and a Right Shift keybind.

## Build on Android with Termux

Requires JDK 21 and **Gradle 9.2 or newer** (Fabric Loom 1.14 refuses to run on older Gradle, so a build on Gradle 8.x fails within seconds). In Termux, install the tools and build:

```bash
pkg update
pkg install openjdk-21 gradle unzip
# Extract this ZIP, then enter the nova-client folder
./build-termux.sh
```

You need an internet connection for Gradle to download Minecraft, Fabric and build dependencies on the first build.

The remapped mod JAR should be produced in `build/libs/` as `nova-client-0.1.0.jar`.

## Build with GitHub Actions

The workflow in `.github/workflows/main.yml` installs JDK 21 and Gradle 9.2.1 and builds the mod. Push the project to GitHub, open the **Actions** tab, open the latest **Build NOVA CLIENT** run and download the **NOVA-CLIENT** artifact. It contains the mod JAR (`nova-client-0.1.0.jar`).

If a run fails, open it, tap the failed job and the red step, and read the last lines of the log. That is the real error.

## Install

Copy the remapped JAR into the `mods` folder of the Minecraft 1.21.11 Fabric profile. Install Fabric API 0.141.1+1.21.11 in that same profile. On PojavLauncher, use a Java 21 runtime and a Fabric 1.21.11 profile.

## Controls

- Right Shift: open NOVA NEXUS.
- Select a category and tap a module tile to toggle its UI state.

## Current milestone / honest status

This is the first implementation milestone, not the full advertised feature set. The module switches currently store in-memory UI state; they do not yet activate every named HUD, combat, movement, recording, or world-render feature. Those need to be implemented and tested in later milestones. The source was updated for the Minecraft 1.21.11 API (`Identifier` instead of `ResourceLocation`, `MouseButtonEvent` for clicks), but it has not been compiled yet because Gradle and dependency downloads were unavailable where it was edited. The first GitHub Actions run is the real test.
